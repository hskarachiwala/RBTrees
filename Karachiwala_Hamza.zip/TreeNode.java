
public class TreeNode {

	public TreeNode leftChild;
	public TreeNode rightChild;
	public TreeNode parent;		
	public int EventId;
	public int ActiveCount;
	NodeColor Color;
	
	public TreeNode(int id, int count)		
	{
		EventId = id;
		ActiveCount = count;
	}
	
}
