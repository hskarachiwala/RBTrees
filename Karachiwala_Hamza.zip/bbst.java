import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class bbst {

	public static void main(String[] args) 
	{	
		ArrayList<TreeNode> nodeData = readFile(args[0]);		// read the node data
		if(nodeData==null || nodeData.size()==0 )					// if no data available
			return;
		
		TreeNode sentinel = new TreeNode(-1,-1);		//sentinel node of the red black tree
		sentinel.Color = NodeColor.Black;
		sentinel.leftChild = null;
		sentinel.rightChild = null;
		sentinel.parent = null;

		for(int i=0; i<nodeData.size()-1;i++ )			//assign each node to have sentinel pointers
		{
			nodeData.get(i).leftChild = sentinel;
			nodeData.get(i).rightChild = sentinel;
		}
		
		TreeHelper helper = new TreeHelper();
		TreeNode root = helper.initialize(nodeData,0,nodeData.size()-1,sentinel,sentinel);						//build the tree	

		int height = helper.maxHeight(root,sentinel);				//calcuate height
		helper.colorLeaves(root,height,sentinel);					// color bottom leaves
		
		root.parent = sentinel;
			
		Scanner in = new Scanner(System.in);				//scan user input
		while(true)
		{
//			System.out.println("Enter your operation, use command exit to quit");		
			String[] command =  in.nextLine().split(" ");
			if(command[0]=="quit")
			{
				in.close();
				return;
			}				
			switch(command[0])
			{
				case "increase":
					int id = Integer.parseInt(command[1]);
					int count = Integer.parseInt(command[2]);
					root = helper.increaseKey(id,count,root,sentinel);		//either insert or increase
//					helper.printInorder(root,sentinel);
					break;
				case "reduce":
					id = Integer.parseInt(command[1]);
					count = Integer.parseInt(command[2]);
					root = helper.decreaseKey(id,count,root,sentinel);		//delete or reduce
//					helper.printInorder(root,sentinel);
					break;
				case "count":
					id = Integer.parseInt(command[1]);
					count = -1;
					helper.increaseKey(id, count, root,sentinel);			//return count or 0
					break;
				case "inrange":
					int id1 = Integer.parseInt(command[1]);					//sum of counts within a range
					int id2 = Integer.parseInt(command[2]);
					helper.InRange(id1,id2,root,sentinel);
					break;
				case "next":
					id = Integer.parseInt(command[1]);						//next closest id
					helper.getNext(id, root, sentinel);
					break;
				case "previous":
					id = Integer.parseInt(command[1]);						//previous closest id
					helper.getPrevious(id, root, sentinel);
					break;
				case "quit":
					return;
				default:
		//			System.out.println("Please ensure you command is valid with lower case");
			}
		}		
	}
	
	public static ArrayList<TreeNode> readFile(String fileName)
	{	
        String line = null;
        ArrayList<TreeNode> nodeData = new ArrayList<TreeNode>();

        try 
        {
            FileReader fileReader =  new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            int numberOfNodes = Integer.parseInt(bufferedReader.readLine()); 
            while((numberOfNodes--)!=0) {
            	line = bufferedReader.readLine();
            	String[] data = line.split(" ");
            	nodeData.add( new TreeNode( Integer.parseInt(data[0]),Integer.parseInt(data[1])));
            }   
            bufferedReader.close();            
            return nodeData;
        }
        catch(FileNotFoundException ex) 
        {
            System.out.println("Unable to open file "+ fileName );
            return null;
        }
        catch(IOException ex) 
        {
            System.out.println( "Error reading file" + fileName );                 
            return null;
        }
	}
}


