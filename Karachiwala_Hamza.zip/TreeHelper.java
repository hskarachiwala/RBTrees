import java.util.ArrayList;

public class TreeHelper 
{	
	/*-------------------------Initialize in O(n)-------------------------------*/
	
	public TreeNode initialize(ArrayList<TreeNode> nodeList,int start,int end, TreeNode parent,TreeNode sentinel)
	{		
		if (start > end) 
            return sentinel;
		
        int mid = (start + end) / 2;
        TreeNode node = nodeList.get(mid);
        node.parent = parent;
        node.Color = NodeColor.Black;		//first keep all nodes black will be recolored later
        
        node.leftChild = initialize(nodeList, start, mid - 1, node,sentinel);
        node.rightChild = initialize(nodeList, mid + 1, end, node,sentinel);
		
		return node;		
	}
		
	/*------------------------------------Rotate methods-----------------------------------*/
	
	public TreeNode leftRotate(TreeNode node, TreeNode sentinel, TreeNode root)		//left rotate protocol of RB tree
	{
		TreeNode y = node.rightChild;
		node.rightChild = y.leftChild;
		
		if(y.leftChild != sentinel)
			y.leftChild.parent = node;
		
		y.parent = node.parent;
		
		if(node.parent == sentinel)
			root = y;
		else if(node==node.parent.leftChild)
			node.parent.leftChild = y;
		else
			node.parent.rightChild = y;
		
		y.leftChild = node;
		node.parent = y;
		
		return root;
	}
	
	public TreeNode rightRotate(TreeNode node, TreeNode sentinel, TreeNode root)	//right rotate protocol of RB tree
	{
		TreeNode y = node.leftChild;
		node.leftChild = y.rightChild;
		
		if(y.rightChild != sentinel)
			y.rightChild.parent = node;
		
		y.parent = node.parent;
		
		if(node.parent == sentinel)
			root = y;
		else if(node==node.parent.rightChild)
			node.parent.rightChild = y;
		else
			node.parent.leftChild = y;
		
		y.rightChild = node;
		node.parent = y;	
		
		return root;
	}
	
	/*-----------------------------------------Insert methods----------------------------------*/

	public TreeNode increaseKey(int id,int count,TreeNode root, TreeNode sentinel)  //-1 count is for search
	{		
		if(root==sentinel && count==-1)
		{
			System.out.println("0");
			return root;
		}
			
		if(root==sentinel)				// if tree is empty create new root
		{
			TreeNode newNode = new TreeNode(id,count);
			root = newNode;
			root.parent = sentinel;
			root.leftChild = sentinel;
			root.rightChild = sentinel;
			root.Color = NodeColor.Black;
			return root;
		}
		else
		{
			TreeNode nodeLocation = root;
			TreeNode p = sentinel;
			while( nodeLocation != sentinel )
			{
				if(nodeLocation.EventId == id)			// if id exists increment count return unchanged root
				{
					if(count==-1)						// successful search return the count only
					{
						System.out.println(nodeLocation.ActiveCount);
						return root;
					}
					else
					{
						nodeLocation.ActiveCount = nodeLocation.ActiveCount + count ;
						System.out.println(nodeLocation.ActiveCount);
						return root;						
					}
				}
				else if(nodeLocation.EventId > id)
				{
					p = nodeLocation;
					nodeLocation = nodeLocation.leftChild;					
				}
				else
				{
					p = nodeLocation;
					nodeLocation = nodeLocation.rightChild;
				}
			}
			if(nodeLocation==sentinel)		//need to insert id is not found
			{
				if(count==-1)			// search function not found
				{
					System.out.println("0");
					return root;
				}
				
				TreeNode newNode = new TreeNode(id,count);
				newNode.parent = p;
				newNode.leftChild = sentinel;
				newNode.rightChild = sentinel;
				newNode.Color = NodeColor.Red;			//color red for inserts

				System.out.println(newNode.ActiveCount);
				
				if( id < p.EventId )
					p.leftChild = newNode;
				else
					p.rightChild = newNode;
				
				root = insertFixup(newNode,root,sentinel);		//call check on properties				
			}			
		}
		return root;					//return unchanged root?
	}
	
	public TreeNode insertFixup(TreeNode newNode, TreeNode root, TreeNode sentinel)
	{
		TreeNode y;
		while(newNode.parent.Color==NodeColor.Red)
		{
			if (newNode.parent == newNode.parent.parent.leftChild)		//for a parent who is the left child of the grandparent 
            {
				y = newNode.parent.parent.rightChild;
				if(y.Color==NodeColor.Red)
				{
					newNode.parent.Color = NodeColor.Black;
					y.Color = NodeColor.Black;
					newNode.parent.parent.Color = NodeColor.Red;
					newNode = newNode.parent.parent;
				}
				else if( newNode == newNode.parent.rightChild ) 
	            {
					newNode = newNode.parent;
					root = leftRotate(newNode,sentinel,root);
	            }
	            newNode.parent.Color = NodeColor.Black;
	            newNode.parent.parent.Color = NodeColor.Red;
	            root = rightRotate(newNode.parent.parent,sentinel,root);
            }
			else
	        {
					y = newNode.parent.parent.leftChild;
					if(y.Color==NodeColor.Red)
					{
						newNode.parent.Color = NodeColor.Black;
						y.Color = NodeColor.Black;
						newNode.parent.parent.Color = NodeColor.Red;
						newNode = newNode.parent.parent;
					}
					else if( newNode == newNode.parent.leftChild ) 
		            {
						newNode = newNode.parent;
						root = rightRotate(newNode,sentinel,root);
		            }
		            newNode.parent.Color = NodeColor.Black;
		            newNode.parent.parent.Color = NodeColor.Red;
		            root = leftRotate(newNode.parent.parent,sentinel,root);
	            }
		}
        root.Color = NodeColor.Black; 			// color the root black
        return root;
	}
	
	/* ------------------------------delete methods------------------------------------ */

	public TreeNode decreaseKey(int id,int count,TreeNode root,TreeNode sentinel)
	{		
		boolean flag = false;
		if(root==sentinel)				// if tree is empty
		{
			System.out.println("0");
			return root;
		}
		else
		{
			TreeNode nodeLocation = root;
			while( nodeLocation!=null )
			{
				if(nodeLocation.EventId > id)
				{
					nodeLocation = nodeLocation.leftChild;					
				}
				else if(nodeLocation.EventId < id)
				{
					nodeLocation = nodeLocation.rightChild;
				}
				else if(nodeLocation.EventId == id)			// if id exists decrement count
				{
					nodeLocation.ActiveCount = nodeLocation.ActiveCount - count ;
					if(nodeLocation.ActiveCount<=0)		//delete this node
					{
						root = deleteNode(root,nodeLocation,sentinel);
			            flag=true;		//delete flag true
					}
					else
					{
						System.out.println(nodeLocation.ActiveCount);
						return root;
					}
					if(flag==true)
					{
						System.out.println("0");
						return root;
					}
				}
			}
			if(nodeLocation==null)
				System.out.println("0");
		}
		return root;					//return unchanged root?
	}
	
	public TreeNode deleteNode(TreeNode root,TreeNode node,TreeNode sentinel)		//method to delete a node
	{
		TreeNode x; 
		TreeNode y = node;
		NodeColor original = y.Color;
		
		if(node.leftChild==sentinel)			//one child only
		{
			x = node.rightChild;
			root = RBtransplant(root,node,node.rightChild,sentinel);
		}
		else if(node.rightChild == sentinel)
		{
			x=node.rightChild;
			root = RBtransplant(root,node,node.leftChild,sentinel);
		}
		else			
		{
			y = minValue(node.rightChild,sentinel);
			original = y.Color;
			x = y.rightChild;
			if( y.parent == node)
					x.parent = y;
			else
			{
				root = RBtransplant(root,y,y.rightChild,sentinel);
				y.rightChild = node.rightChild;
				y.rightChild.parent = y;
			}
			root = RBtransplant(root,node,y,sentinel);
			y.leftChild = node.leftChild;
			y.leftChild.parent = y;
			y.Color = node.Color;
		}
		if(original==NodeColor.Black)
		{
			root = deleteFixup(x, root,sentinel);
		}
		return root;
	}
	
	public TreeNode RBtransplant(TreeNode root,TreeNode u,TreeNode v,TreeNode sentinel)	//this method splices a node from the subtree to delete
	{
		if(u.parent==sentinel)
			root = v;
		else if(u==u.parent.leftChild)
			u.parent.leftChild = v;
		else
			u.parent.rightChild = v;

		v.parent = u.parent;
		
		return root;
	}

	public TreeNode deleteFixup(TreeNode newNode,TreeNode root,TreeNode sentinel) //rearrange nodes to maintain properties
	{
        while( newNode!= root && newNode.Color == NodeColor.Black ) 
        {
        	if (newNode == newNode.parent.leftChild) 
        	{
                TreeNode sibling = newNode.parent.rightChild ;	// Pulled up node is a left child
                if( sibling.Color == NodeColor.Red) 
                {
                	sibling.Color = NodeColor.Black;
                	newNode.parent.Color = NodeColor.Red;
                    root = leftRotate(newNode.parent,sentinel,root);
                    sibling = newNode.parent.rightChild;
                }
                if( sibling.leftChild.Color==NodeColor.Black  && sibling.rightChild.Color==NodeColor.Black ) 
                {
                	sibling.Color = NodeColor.Red;
                	newNode = newNode.parent;
                } 
                else
                {
                	if( sibling.rightChild.Color == NodeColor.Black ) 
                    {
                    	sibling.leftChild.Color = NodeColor.Black;
                    	sibling.Color = NodeColor.Red;
                        root = rightRotate(sibling,sentinel,root);
                        sibling = newNode.parent.rightChild;
                    }
                    sibling.Color = newNode.parent.Color;
                    newNode.parent.Color = NodeColor.Black;
                    sibling.rightChild.Color = NodeColor.Black;
                    root = leftRotate(newNode.parent,sentinel,root);
                    newNode = root;	
                }
            } 
        	else 
        	{
                TreeNode sibling = newNode.parent.leftChild;			// pulled up node is a right child
                if( sibling.Color==NodeColor.Red ) 
                {
                	sibling.Color = NodeColor.Black;
                	newNode.parent.Color = NodeColor.Red;
                    root = rightRotate(newNode.parent,sentinel,root);
                    sibling = newNode.parent.leftChild;
                }
                if ( sibling.leftChild.Color == NodeColor.Black  && sibling.rightChild.Color == NodeColor.Black ) 
                {
                	sibling.Color = NodeColor.Red;
                	newNode = newNode.parent;
                } 
                else 
                {
                	if( sibling.leftChild.Color == NodeColor.Black ) 
                	{
                		sibling.rightChild.Color = NodeColor.Black;
                		sibling.Color = NodeColor.Red;
                        root = leftRotate(sibling,sentinel,root);
                        sibling = newNode.parent.leftChild ;
                    }
                	sibling.Color = newNode.parent.Color;
                	newNode.parent.Color = NodeColor.Black;
                	sibling.leftChild.Color = NodeColor.Black;
                    root = rightRotate(newNode.parent,sentinel,root);
                    newNode = root;
                }
            }
        }
        newNode.Color = NodeColor.Black;
        return root;
    }
	
	/*-------------------------------InRange Prev Next methods---------------------------------------*/
	
	public void InRange(int id1, int id2, TreeNode root,TreeNode sentinel)
	{
		int totalCount = 0;
		TreeNode p = root;
		TreeNode pp = sentinel;
		
		while( p != sentinel )
		{
			if(p.EventId == id1)			// if first id is found
			{
				break;
			}
			else if(p.EventId > id1)
			{
				pp = p;
				p = p.leftChild;					
			}
			else
			{
				pp = p;
				p = p.rightChild;
			}
		}
		
		if(p==sentinel)						//first id not found
		{
			if(pp.EventId > id1)
				p = pp;
			else
				p = getSuccessor(pp,sentinel);
		}
		
		if( p==sentinel || p.EventId>id2)
		{
			System.out.println("0");
			return;
		}
		
		totalCount = p.ActiveCount;
		while(p!=sentinel && p.EventId <= id2)
		{
			TreeNode s = getSuccessor(p,sentinel);
			if(s!=sentinel && s.EventId<=id2)
				totalCount = totalCount + s.ActiveCount;
			p = s;
		}
		
		System.out.println(totalCount);
		return;
	}
	
	public TreeNode getPredecessor(TreeNode n, TreeNode root, TreeNode sentinel)	//find the immediate predecessor of node in bst
	{
		if( n.leftChild != sentinel )				//if it has a left subtree
	        return maxValue(n.leftChild,sentinel);		//right most node in it
	  
	    TreeNode p = sentinel;
	  
	    while (root != sentinel)
	    {
	        if (n.EventId > root.EventId)
	        {
	            p = root;
	            root = root.rightChild;
	        }
	        else if (n.EventId < root.EventId)
	            root = root.leftChild;
	        else
	           break;
	    }
	    return p;
	}
	
	public TreeNode getSuccessor(TreeNode n, TreeNode sentinel)		//find the immediate successor of node in bst
	{
		if (n.rightChild != sentinel) 
		{
			return minValue(n.rightChild,sentinel);
	    }
	    TreeNode p = n.parent;
	        
	    while (p != sentinel && n == p.rightChild) 
	    {
	    	n = p;
	        p = p.parent;
	    }
	    return p;
	}
	
	public void getNext(int id, TreeNode root, TreeNode sentinel)
	{
		TreeNode p = root;
		TreeNode pp = sentinel;
		
		while( p != sentinel )
		{
			if(p.EventId == id)			// if first id is found
			{
				break;
			}
			else if(p.EventId > id)
			{
				pp = p;
				p = p.leftChild;					
			}
			else
			{
				pp = p;
				p = p.rightChild;
			}
		}
		
		if(p==sentinel)						// id not found
		{
			if(pp.EventId > id)
				p = pp;
			else
				p = getSuccessor(pp,sentinel);
			
			if(p==sentinel)
			{
				System.out.println("0 0");
				return;
			}
			else
			{
				System.out.println(p.EventId + " " + p.ActiveCount);
				return;
			}
		}
		
		TreeNode s = getSuccessor(p,sentinel);			//id found
		if(s==sentinel)
		{
			System.out.println("0 0");
			return;
		}
		else
		{
			System.out.println(s.EventId + " " + s.ActiveCount);
			return;
		}

	}
	
	public void getPrevious(int id, TreeNode root, TreeNode sentinel)
	{
		TreeNode p = root;
		TreeNode pp = sentinel;
		
		while( p != sentinel )
		{
			if(p.EventId == id)			// if first id is found
			{
				break;
			}
			else if(p.EventId > id)
			{
				pp = p;
				p = p.leftChild;					
			}
			else
			{
				pp = p;
				p = p.rightChild;
			}
		}
		
		if(p==sentinel)						// id not found
		{
			if(pp.EventId < id)
				p = pp;
			else
				p = getPredecessor(pp,root,sentinel);
			
			if(p==sentinel)
			{
				System.out.println("0 0");
				return;
			}
			else
			{
				System.out.println(p.EventId + " " + p.ActiveCount);
				return;
			}
		}
		
		TreeNode s = getPredecessor(p,root,sentinel);		//id found
		if(s==sentinel)
		{
			System.out.println("0 0");
			return;
		}
		else
		{
			System.out.println(s.EventId + " " + s.ActiveCount);
			return;
		}
	}	
	
	
	/*------------------------------- Auxiliary methods for debug and test-------------------------- */
	
	public void printInorder(TreeNode root,TreeNode sentinel)
	{
		if(root==sentinel)
			return;
		
			printInorder(root.leftChild,sentinel);
			System.out.print(root.EventId + " ");
			printInorder(root.rightChild,sentinel);
	}
	
	public int maxHeight(TreeNode node, TreeNode sentinel)			// calculate tree height for initialize
	{
		if (node == sentinel) 
		{
            return 0;
        } 
		else 
		{
            int leftHeight = maxHeight(node.leftChild,sentinel);
            int rightHeight = maxHeight(node.rightChild,sentinel);
            if ( leftHeight > rightHeight) 
                return (leftHeight + 1);
            else
                return (rightHeight + 1);
        }	
	}
	
	public void colorLeaves(TreeNode root, int height, TreeNode sentinel)	//color the last level red to maintain tree property
	{
		if(root==sentinel)
			return;			
		colorLeaves(root.leftChild,height-1,sentinel);
		if(height==1)
			root.Color = NodeColor.Red;
		colorLeaves(root.rightChild,height-1,sentinel);
	}
	
	public void SetNode(TreeNode t1,TreeNode t2)		//copy one node to another for splice operation
	{
		t1.EventId = t2.EventId;
		t1.ActiveCount = t2.ActiveCount;
	}
	
	TreeNode minValue(TreeNode root,TreeNode sentinel)		//fetch minimum value in a subtree
    {
        while (root.leftChild != sentinel)
        {
            root = root.leftChild;
        }
        return root;
    }
	
	TreeNode maxValue(TreeNode root,TreeNode sentinel)		//fetch maximum value in a subtree
    {
        while (root.rightChild != sentinel)
        {
            root = root.rightChild;
        }
        return root;
    }

	
}
