//2 possible colors of a node.
public enum NodeColor{
	Black,Red;
}
